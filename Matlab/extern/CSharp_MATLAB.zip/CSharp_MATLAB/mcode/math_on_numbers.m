function [c, d] = math_on_numbers(a, b)

% This code is provided for example purposes only

% Copyright 2006-2010 The MathWorks, Inc.

c(1) = a(1) + b(1);
c(2) = a(1) - b(1);
d(1) = a(2) * b(2);
d(2) = a(2) / b(2);
