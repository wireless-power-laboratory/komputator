#ifndef LAPACK_H
#define LAPACK_H

//#include "blas.h"
#include "mkl_lapack.h"

#endif 

